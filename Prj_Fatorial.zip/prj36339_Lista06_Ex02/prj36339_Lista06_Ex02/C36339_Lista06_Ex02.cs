﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prj36339_Lista06_Ex02
{
    class C36339_Lista06_Ex02
    {
        static void Main(string[] args)
        {
            int y = 0;
            int n = 0;
            int x = 0;

            do
            {
                Console.WriteLine("Digite um valor: ");
                n = int.Parse(Console.ReadLine());
                if (n < 0)
                {
                    Console.WriteLine("O valor deve ser Nulo ou Positivo!");
                }
            } while (n < 0);

            if (n == 0)
            {
                Console.WriteLine(n + "! = 1");
            }
            else
            {
                y = n;
                x = n;
                do
                {
                    n = n * (x - 1);
                    x = x - 1;
                } while (x > 1);

                Console.WriteLine(y + "! = " + n);                
            }

            Console.ReadKey();
        }
    }
}
